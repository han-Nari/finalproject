<?php
session_start();

// Check if the user has a valid session token
if (isset($_GET['token'])) {
    $token = $_GET['token'];
    // Store the token in the session
    $_SESSION['sso_token'] = $token;

    echo 'Token from URL: ' . $token . '<br>';
    echo 'Token from session: ' . $_SESSION['sso_token'] . '<br>';

    // Check if the 'sso_token' key is set in the session
    if (isset($_SESSION['sso_token']) && $token === $_SESSION['sso_token']) {

        $_SESSION['email'] = 'user'; 
        $_SESSION['sso_token'] = $token;

        // Debugging output
        echo 'Token generated: ' . $token . '<br>';

        header('Location: dashboard/dash.php');
    } else {
        echo 'Invalid token.';
    }
} else {
    // Redirect to example.com for authentication
    header('Location: dashboard/dash.php');
    exit();
}
?>