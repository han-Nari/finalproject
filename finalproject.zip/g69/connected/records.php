<?php 
	require_once "../includes/session.php";
	require_once "../includes/finance_db_connect.php";
	require_once "../database/fetch.php";
	
	unset($_SESSION["passCode"]);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<script type="text/javascript">
		window.history.forward();
	</script>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Expenses Management Records</title>

	<!-- Favicon -->
	<link rel="icon" type="image/x-icon" href="../img/logo.png">

	<!-- Jquery -->
	<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
	
	<!-- ==== Icon ==== -->
	<script src="https://kit.fontawesome.com/9fd2f42e98.js" crossorigin="anonymous"></script>

	<!-- ==== Css Link ==== -->
	<style>
		<?php include "../dashboard/dash.css"; ?>
		<?php include "../table/table.css"; ?>
		<?php include "../database/main.css"; ?>
		section {
			padding: 1rem;
		}
	</style>
</head>
<body>
	<main>
	<!-- Sidebar -->
	<?php include "../dashboard/side.php";?>

	<!-- Header -->
	<?php include "../dashboard/header.php";?>

	<!-- Main content -->
		<section>
			<table>
        <caption>History Logs</caption>
        <thead>
            <tr>
                <th>Type</th>
                <th>Details</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($historyLogs as $log): ?>
                <tr>
                    <td>
                        <?php 
                        if (isset($log['projname'])) {
                            echo "Expenses Management";
                        } elseif(isset($log['mname'])) {
                            echo "Rental Payments";
                        } elseif(isset($log['full_name'])) {
                            echo "Business Permit";
                        } elseif(isset($log['market_name'])) {
                            echo "Vendors DownPayment";
                        } else {
                            echo "Land Computation";
                        }
                        ?>
                    </td>
                    <td>
                        <?php 
                        if (isset($log['projname'])) {
                            echo "Social Projects: <strong>" . htmlspecialchars($log["projname"]) . "</strong><br>Total Budget: <strong>" . htmlspecialchars($log["budget"]) . "</strong>";
                        } elseif(isset($log['mname'])) {
                            echo "Market: <strong>" . htmlspecialchars($log["mname"]) . "</strong><br>Total Payment: <strong>" . htmlspecialchars($log["rent_amount"]) . "</strong>";
                        } elseif(isset($log['permit_type'])) {
                            echo "Name: <strong>" . htmlspecialchars($log["full_name"]) . "</strong><br>Total Amount: <strong>" . htmlspecialchars($log["amount"]) . "</strong><br>Permit Type: <strong>" . htmlspecialchars($log["permit_type"]) . "</strong>";
                        } elseif(isset($log['market_name'])) {
                            echo "Vendors Name: <strong>" . htmlspecialchars($log["first_name"]) . "</strong><br>Total Amount: <strong>" . htmlspecialchars($log["rent_amount"]) . "</strong";
                        } else {
                            echo "Land Property: <strong>" . htmlspecialchars($log["name"]) . "</strong><br>Total Tax: <strong>" . htmlspecialchars($log["total_tax"]) . "</strong>";
                        }
                        ?>
                    </td>
                    <td><?php echo date("Y/m/d", strtotime($log["created_at"])); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
		</section>
	</main>
	<script>
		<?php include "../dashboard/dash.js"; ?>
	</script>
</body>
</html>



	