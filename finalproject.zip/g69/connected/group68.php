<?php 
require_once "../includes/session.php";
require_once "../includes/finance_db_connect.php";

$url = "https://group70.towntechinnovations.com/adminlte/api/landcomp.php";

// Fetch JSON data from the URL
$json_data = file_get_contents($url);

// Initialize $data variable
$data = [];

// Check if data was fetched successfully
if ($json_data !== false) {
    // Decode JSON data
    $data = json_decode($json_data, true);
} else {
    // Handle error fetching data from the URL
    echo "Error fetching data from the URL.";
}

// Function to save data to database
function saveToDatabase($name, $title, $address, $area, $price) {
    global $pdo;
    try {
        $query = "INSERT INTO tax (name, title, address, area, price) VALUES (:name, :title, :address, :area, :price)";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(':name', $name);
        $stmt->bindParam(':title', $title);
        $stmt->bindParam(':address', $address);
        $stmt->bindParam(':area', $area);
        $stmt->bindParam(':price', $price);
        $stmt->execute();
        $_SESSION['data_saved'] = true;
        return true;
    } catch (PDOException $e) {
        echo "Error: " . $e->getMessage();
        return false;
    }
}


// Function to reject data
function rejectData($name) {
    $_SESSION['rejected'][$name] = true;  // Set session flag when rejected
    return true;  // Assume rejection always succeeds
}

if (isset($_POST['accept']) && !isset($_SESSION['accept_clicked'][$_POST['name']])) {
    if (saveToDatabase($_POST['name'], $_POST['title'], $_POST['address'], $_POST['area'], $_POST['price'])) {
        $_SESSION['accept_clicked'][$_POST['name']] = true;
        header("Location: ".$_SERVER['PHP_SELF']);
        exit();
    } else {
        echo "Failed to save data.";
    }
}


if (isset($_POST['reject']) && !isset($_SESSION['rejected'][$_POST['name']])) {
    if (rejectData($_POST['name'])) {
        // Mark as rejected
        $_SESSION['rejected'][$_POST['name']] = true;
        // Set session variable to indicate rejection
        $_SESSION['data_rejected'] = true;
        header("Location: ".$_SERVER['PHP_SELF']);
        exit();
    } else {
        echo "Failed to reject data."; // Debug statement
    }
}

// Function to check if data exists in the database
function isDataExists($name) {
    global $pdo;
    $query = "SELECT COUNT(*) FROM tax WHERE name = :name";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(':name', $name);
    $stmt->execute();
    return $stmt->fetchColumn() > 0;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Database</title>

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="../img/logo.png">

    <!-- Jquery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    
    <!-- ==== Icon ==== -->
    <script src="https://kit.fontawesome.com/9fd2f42e98.js" crossorigin="anonymous"></script>

    <!-- ==== Css Link ==== -->
    <style>
        <?php include "../dashboard/dash.css"; ?>
        <?php include "../table/table.css" ?>
         /* Flex container for buttons */
        .button-container {
            display: flex;
            gap: 0.5rem; /* Gap between buttons */
        }

        /* Style for the buttons */
        .button-container button {
            padding: 0.5rem 1rem; /* Adjust padding as needed */
            border: none; /* Remove button border */
            border-radius: 5px; /* Add button border radius */
            cursor: pointer; /* Show pointer cursor on hover */
            transition: background-color 0.3s ease; /* Smooth transition for background color change */
        }

        /* Accept button style */
        .button-container button[name="accept"] {
            background-color: #007bff; /* Blue background color */
            color: #fff; /* White text color */
        }

        /* Reject button style */
        .button-container button[name="reject"] {
            background-color: #dc3545; /* Red background color */
            color: #fff; /* White text color */
        }

        /* Hover effect */
        .button-container button:hover {
            filter: brightness(0.9); /* Reduce brightness on hover */
        }

        /* Disabled button style */
        .button-container button:disabled {
            opacity: 0.5; /* Reduce opacity for disabled button */
            cursor: not-allowed; /* Show not-allowed cursor for disabled button */
        }

        /* Modal styles */
        .modal {
            display: <?php echo (isset($_SESSION['data_saved']) && $_SESSION['data_saved'] === true) ? 'block' : 'none'; ?>; /* Show modal if data is saved */
            position: absolute; /* Stay in place */
            z-index: 1; /* Sit on top */
            left: 0;
            top: 0;
            width: 100%; /* Full width */
            height: 100%; /* Full height */
            overflow: auto; /* Enable scroll if needed */
            background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
        }

        /* Modal content */
        .modal-content {
            background-color: #fefefe;
            margin: 15% auto; /* 15% from the top and centered */
            padding: 20px;
            border: 1px solid #888;
            width: 40%; /* Could be more or less, depending on screen size */
            position: relative; /* Relative positioning for close button */
        }

        /* Close button */
        .close {
            position: absolute;
            top: 5px;
            right: 10px;
            cursor: pointer;
        }

        /* Ensure modal stays within section element */
        section {
            position: relative;
            overflow: hidden;
        }
    </style>
</head>
<body>
    <main>
    <!-- Sidebar -->
    <?php include "../dashboard/side.php";?>

    <!-- Header -->
    <?php include "../dashboard/header.php";?>

    <!-- Main content -->
    <section>
        <div class="container">
            <div class="auto">
                <table>
                    <caption>
                        <span>Land Computation</span>            
                    </caption>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Title</th>
                            <th>Area</th>
                            <th>Price</th>
                            <th>Address</th>
                            <th colspan="2" style="text-align: center;">Action</th>
                        </tr>
                    </thead>
                    <tbody id="table-body">
                          <?php foreach ($data['data'] as $item): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($item['name']); ?></td>
                                <td><?php echo htmlspecialchars($item['title']); ?></td>
                                <td><?php echo htmlspecialchars($item['area']); ?></td>
                                <td><?php echo htmlspecialchars($item['price']); ?></td>
                                <td><?php echo htmlspecialchars($item['address']); ?></td>
                                <td>
								    <form method="POST">
								        <input type="hidden" name="name" value="<?php echo htmlspecialchars($item['name']); ?>">
								        <input type="hidden" name="title" value="<?php echo htmlspecialchars($item['title']); ?>">
								        <input type="hidden" name="area" value="<?php echo htmlspecialchars($item['area']); ?>">
								        <input type="hidden" name="price" value="<?php echo htmlspecialchars($item['price']); ?>">
								        <input type="hidden" name="address" value="<?php echo htmlspecialchars($item['address']); ?>">
								        <div class="button-container">
								            <?php if (isDataExists($item['name'])): ?>
								                <button type="button" style="background-color: green; color: white;">Accepted</button>
								            <?php elseif (isset($_SESSION['rejected'][$item['name']])): ?>
								                <button type="button" style="background-color: red; color: white;">Rejected</button>
								            <?php else: ?>
								                <button type="submit" name="accept">Accept</button>
								                <button type="submit" name="reject">Reject</button>
								            <?php endif; ?>
								        </div>
								    </form>
								</td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>  
        <!-- Modal -->
        <div class="modal" onclick="closeModal()">
            <div class="modal-content">
                <span class="close" onclick="closeModal()">&times;</span>
                <p>Data saved successfully.</p>
            </div>
        </div>
        <!-- Modal for rejection message -->
                <div class="modal" id="rejectMessage" style="display: <?php echo isset($_SESSION['data_rejected']) && $_SESSION['data_rejected'] ? 'block' : 'none'; ?>">
                    <div class="modal-content">
                        <span class="close" onclick="closeRejectMessage()">&times;</span>
                        <p>Data rejected.</p>
                    </div>
                </div>

    </section>
    </main>

    <!-- JavaScript -->
    <script>
       // Function to close modal
        function closeModal() {
            document.querySelector('.modal').style.display = 'none';
            // Remove session variables
            <?php unset($_SESSION['data_saved']); ?>
            <?php unset($_SESSION['accept_clicked']); ?>
        }

        // Function to close rejection message modal
        function closeRejectMessage() {
            document.getElementById('rejectMessage').style.display = 'none';
            <?php unset($_SESSION['data_rejected']); ?>
        }

        // Add event listener to modal overlay
        window.addEventListener('click', function(event) {
            var modal = document.getElementById('rejectMessage');
            if (event.target == modal) {
                modal.style.display = 'none';
                <?php unset($_SESSION['data_rejected']); ?>
            }
        });

    </script>
</body>
</html>
