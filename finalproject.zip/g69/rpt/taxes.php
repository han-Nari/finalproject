<?php
$income = 0; // Initialize income variable
$budget = 500000;

try {
    // Execute the SQL query to sum up total income from vendors
    $queryVendors = "SELECT SUM(amount) AS amounts FROM vendors";
    $stmtVendors = $pdo->query($queryVendors);
    $resultVendors = $stmtVendors->fetch(PDO::FETCH_ASSOC);
    $totalIncomeVendors = (float)$resultVendors['amounts']; // Cast to float
} catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}

try {
    // Execute the SQL query to sum up total income from permits
    $queryPermits = "SELECT SUM(amount) AS total_income FROM permits";
    $stmtPermits = $pdo->query($queryPermits);
    $resultPermits = $stmtPermits->fetch(PDO::FETCH_ASSOC);
    $totalIncomePermits = (float)$resultPermits['total_income']; // Cast to float
} catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}

try {
    // Execute the SQL query to sum up total income from rent
    $queryRent = "SELECT SUM(rent_amount) AS total_amount FROM rent";
    $stmtRent = $pdo->query($queryRent);
    $resultRent = $stmtRent->fetch(PDO::FETCH_ASSOC);
    $totalIncomeRent = (float)$resultRent['total_amount']; // Cast to float
} catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}

// Add the total income from vendors, permits, and rent to the income
$income += $totalIncomeVendors + $totalIncomePermits + $totalIncomeRent;

try {
    // Execute the SQL query to sum up total expenses
    $queryExpenses = "SELECT SUM(budget) AS amounts FROM expenses";
    $stmtExpenses = $pdo->query($queryExpenses);
    $resultExpenses = $stmtExpenses->fetch(PDO::FETCH_ASSOC);
    $totalAmountExpenses = (float)$resultExpenses['amounts']; // Cast to float

    // Subtract expenses from the budget if they are positive
    if ($totalAmountExpenses > 0) {
        $budget -= $totalAmountExpenses;
    }
} catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}

try {
    // Execute the SQL query to sum up total taxes
    $queryTax = "SELECT SUM(total_tax) AS taxes FROM tax";
    $stmtTax = $pdo->query($queryTax);
    $resultTax = $stmtTax->fetch(PDO::FETCH_ASSOC);
    $totalTaxSum = (float)$resultTax['taxes']; // Cast to float

    // Calculate 2% reduction from total taxes
    $taxReduction = $totalTaxSum * 0.02;
    $collectedTaxes = $totalTaxSum - $taxReduction; // Adjusted taxes collected after 2% reduction
} catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
?>
