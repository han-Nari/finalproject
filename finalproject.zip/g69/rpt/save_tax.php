<?php 
require_once "../includes/session.php";
require_once "../includes/finance_db_connect.php";

$errors = array("error" => "");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $assessedValue = $_POST['assessedValue'];
    $basicTax = $_POST['basicTax'];
    $sef = $_POST['sef'];
    $totalTax = $_POST['totalTax'];
    $propertyName = $_POST["propertyName"];
    $name = $propertyName; // define $name based on $propertyName

    // Prepare SQL statement to check if the name exists
    $query = "SELECT COUNT(*) as count FROM tax WHERE name = :name";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(":name", $name);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($row['count'] > 0) {
        $update_query = "UPDATE tax SET assessed_value = :assessed_value, basic_tax = :basic_tax, sef = :sef, total_tax = :total_tax WHERE name = :name";
        $update_stmt = $pdo->prepare($update_query);
        $update_stmt->bindParam(":assessed_value", $assessedValue);
        $update_stmt->bindParam(":basic_tax", $basicTax);
        $update_stmt->bindParam(":sef", $sef);
        $update_stmt->bindParam(":total_tax", $totalTax);
        $update_stmt->bindParam(":name", $name);
        $update_stmt->execute();

        $_SESSION['success_message'] = "New Data has been added!";
        header("location: tax.php");
        exit();
    } else {
        $_SESSION['error'] = "$propertyName Does not Exist.";
    }
}
?>
