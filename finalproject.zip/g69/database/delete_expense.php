<?php 
if(isset($_POST["delete"])) {
		$id = htmlspecialchars($_POST["delete"]);

		try {
			$query = "DELETE FROM expenses WHERE id = :id";
			$stmt = $pdo->prepare($query);
			$stmt->bindParam(":id", $id);
			$stmt->execute();
			
			if($stmt) {
				$_SESSION["delete"] = "Delete Successful!";
				header("location: expenses_db.php");
			} 
			die();
		} catch (Exception $e) {
			die("Error" . $e->getMessage());
		}
	}