<?php

try {
    // Initialize an array to hold combined results
    $historyLogs = [];  
    // Connect to your database (Ensure your $pdo variable is correctly configured before this point)
    // First query for expenses
    $queryExpenses = "SELECT * FROM expenses";
    $stmtExpenses = $pdo->prepare($queryExpenses);
    $stmtExpenses->execute();
    $resultsExpenses = $stmtExpenses->fetchAll(PDO::FETCH_ASSOC);

    // Second query for tax
    $queryTax = "SELECT * FROM tax";
    $stmtTax = $pdo->prepare($queryTax);
    $stmtTax->execute();
    $resultsTax = $stmtTax->fetchAll(PDO::FETCH_ASSOC);

    $queryVendors = "SELECT * FROM vendors";
    $stmtVendors = $pdo->prepare($queryVendors);
    $stmtVendors->execute();
    $resultsVendors = $stmtVendors->fetchAll(PDO::FETCH_ASSOC);

    $queryRent = "SELECT * FROM rent";
    $stmtRent = $pdo->prepare($queryRent);
    $stmtRent->execute();
    $resultsRent = $stmtRent->fetchAll(PDO::FETCH_ASSOC);

    $queryPermit = "SELECT * FROM permits";
    $stmtPermit = $pdo->prepare($queryPermit);
    $stmtPermit->execute();
    $resultsPermit = $stmtPermit->fetchAll(PDO::FETCH_ASSOC);

    // Combine the results
    $historyLogs = array_merge($resultsExpenses, $resultsTax, $resultsVendors, $resultsRent, $resultsPermit);

} catch (Exception $e) {
    die("Connection failed: " . $e->getMessage());
}

?>
