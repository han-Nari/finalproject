<?php 
	include "../includes/finance_db_connect.php";
	include "../includes/session.php";
	include "update_expense.php";

	if (!isset($_SESSION["passCode"])) {
	    header('location: tax_db.php');
	    exit;
	}

	// Unset only the 'passCode' session variable
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Edit Admin</title>

	<!-- Favicon -->
	<link rel="icon" type="image/x-icon" href="../img/logo.png">

	<!-- Jquery -->
	<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
	
	<!-- ==== Icon ==== -->
	<script src="https://kit.fontawesome.com/9fd2f42e98.js" crossorigin="anonymous"></script>

	<!-- ==== Css Link ==== -->
	<style>
		<?php include "../dashboard/dash.css"; ?>
		<?php include "../finance/expense.css"; ?>
	</style>
</head>
<body>
	<main>
	<!-- Sidebar -->
	<?php include "../dashboard/side.php";?>

	<!-- Header -->
	<?php include "../dashboard/header.php";?>

	<!-- Main content -->
		<section>
			<div class="container">
		    <h2>Expenses Management</h2>
	        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
	        	<input type="hidden" name="id" value="<?php echo $results['id']; ?>">
	            <label for="projname">Project Name:</label>
	            <input type="text" name="projname" placeholder="Project Name" value="<?php echo $results["projname"]?>">
	            
	            <label for="startd">Start Date:</label>
	            <input type="date"  name="startd" placeholder="Start Date" value="<?php echo  $results["startd"]?>">
	            
	            <label for="endd">End Date:</label>
	            <input type="date" name="endd" placeholder="End Date" value="<?php echo  $results["endd"]?>">
	            
	            <label for="projdesc">Project Description:</label>
	            <textarea name="projdesc" rows="4" placeholder="Description"><?php echo htmlspecialchars($results["projdesc"]); ?></textarea>
	            
	            <label for="estcost">Estimated Cost:</label>
	            <input type="text"  name="estcost" placeholder="Estimated Cost" value="<?php echo  $results["estcost"]?>">

	            <label for="estcost">Budget</label>
	            <input type="text" name="money" placeholder="Budget Given" value="<?php echo  $results["budget"]?>">
	            
	            <input class="btn" type="submit" name="update" value="Update">
	        </form>
	    </div>
		</section>
	</main>
	<script>
		<?php include "../dashboard/dash.js"; ?>
	</script>
</body>
</html>



	