<?php 
	require_once "../includes/session.php";
	require_once "../includes/finance_db_connect.php";
	require_once "payments_fetch.php";

	$errors = array("error" => "", "number" => "");
	if(isset($_GET["id"])) {
		try {
			$id = htmlspecialchars($_GET["id"]);

			$query = "SELECT * FROM vendors WHERE id = :id";
			$stmt = $pdo->prepare($query);
			$stmt->bindParam(":id", $id);
			$stmt->execute();

			$results = $stmt->fetch(PDO::FETCH_ASSOC);
		} catch(PDOException $e) {
			die("Error" . $e->getMessage());
		}
	}

	if(isset($_POST["update"])) {
        $name = $_POST["name"];
        $mName = $_POST["market"];
        $stall = $_POST["stall"];
        $permit = $_POST["permit"];
        $amount = $_POST["amount"];
    
        if(empty($name)) {
            $errors["error"] = "Required to fill up the form";
        }

        if(empty($stall)) {
            $errors["expenses"] = "Fill up the form!";
        } elseif(!preg_match('/^\d+$/', $stall)) {
            $errors["number"] = "Only number is allowed!";
        }

        if(empty($permit)) {
            $errors["expenses"] = "Fill up the form!";
        } elseif(!preg_match('/^\d+$/', $permit)) {
            $errors["number"] = "Only number is allowed!";
        }

        if(empty($amount)) {
            $errors["expenses"] = "Fill up the form!";
        } elseif(!preg_match('/^\d+$/', $amount)) {
            $errors["number"] = "Only number is allowed!";
        }
	   
	   if(array_filter($errors)) {

	   } else {

		   $query = "UPDATE vendors SET name = :name, market_name = :market_name, stall_numbers = :stall_numbers, permit_numbers = :permit_numbers, amount = :amount WHERE id = :id";
		   $stmt = $pdo->prepare($query);
		   $stmt->bindParam(":name", $name);
		   $stmt->bindParam(":market_name", $mName);
	       $stmt->bindParam(":stall_numbers", $stall);
		   $stmt->bindParam(":permit_numbers", $permit);
	       $stmt->bindParam(":amount", $amount);
	       $stmt->bindParam(":id", $id);
		   $stmt->execute();
		   if($stmt) {
		   	  $_SESSION["success"] = "Update Sucessful!";
		   	   header('location: payments_db.php');
		   }
	   }
	}

?>
<!DOCTYPE html>
<html lang="en">
<head>
	<script type="text/javascript">
		window.history.forward();
	</script>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Edit Vendor's Down Payment</title>

	<!-- Favicon -->
	<link rel="icon" type="image/x-icon" href="../img/logo.png">

	<!-- Jquery -->
	<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
	
	<!-- ==== Icon ==== -->
	<script src="https://kit.fontawesome.com/9fd2f42e98.js" crossorigin="anonymous"></script>

	<!-- ==== Css Link ==== -->
	<style>
		<?php include "../dashboard/dash.css"; ?>
		<?php include "../finance/payments.css"; ?>
		<?php include "../finance/main.css"; ?>
		.grids {
			display: flex;
			justify-content: center;
			align-items: center;
		}

		form {
			width: 100%;
		}

		form h1 {
			text-align: center;
		}
	</style>
</head>
<body>
	<main>
	<!-- Sidebar -->
	<?php include "../dashboard/side.php";?>

	<!-- Header -->
	<?php include "../dashboard/header.php";?>

	<!-- Main content -->
		<section>
			<div class="container">
	           <div class="grids">
		           <div class="two">
		                <div id="form1" class="form-container">	
		                    <form action="<?php htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST"> 
		                      <?php if(isset($_SESSION['pay'])) : ?>
								<div class="sub">
									<strong><?php echo $_SESSION['pay'];?></strong>
									<i class="fa-solid fa-xmark remove"></i>
								</div>
								<?php unset($_SESSION['pay']); ?>
							  <?php endif; ?> 
		                      <span class="errors">
		                        <?php echo $errors["error"]; ?>
		                      </span>

							  <h1>Vendors DownPayment</h1>	

							  <span class="errors">
		                        <?php echo $errors["error"]; ?>
		                      </span>

							  <label>Name</label>                  
		                      <input type="text" name="name" placeholder="Name" value="<?php echo $results["name"] ?>">
            
            				  <label>Market Name</label>  
		                      <input type="text" name="market" placeholder="Market Name" alue="<?php echo $results["market_name"] ?>">

		                      <label>Stall Numbers</label>  
			                  <input type="number" name="stall" placeholder="Stall Numbers" class="no-spinner"value="<?php echo $results["stall_numbers"] ?>">

		                      <label>Permit Numbers</label>  
		                      <input type="number" name="permit" placeholder="Permit Numbers" class="no-spinner" value="<?php echo $results["permit_numbers"] ?>">

		                      <label>Down Payment</label>  
		                      <input type="number" name="amount" placeholder="Amount" class="no-spinner" value="<?php echo $results["amount"] ?>">

		                      <button class="btn" type="submit" name="update">Submit</button>
		                    </form>
		                </div>
		            </div>
	      		</div>
	      	</div>
		</section>
	</main>
	<script>
		<?php include "../dashboard/dash.js"; ?>
	</script>
</body>
</html>



	