<?php 
$errors = array("expenses" => "", "amount" => "", "desc" => "");

if(isset($_GET["id"])) {
	try {
		$id = htmlspecialchars($_GET["id"]);

		$query = "SELECT * FROM expenses WHERE id = :id";
		$stmt = $pdo->prepare($query);
		$stmt->bindParam(":id", $id);
		$stmt->execute();

		$results = $stmt->fetch(PDO::FETCH_ASSOC);
	} catch(PDOException $e) {
		die("Error" . $e->getMessage());
	}
}

$errors = []; // To store validation errors
$success = ""; // To store the success message

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update'])) {
    // Collect form data and sanitize it
    $id = filter_input(INPUT_POST, 'id', FILTER_SANITIZE_NUMBER_INT);
    $projname = filter_input(INPUT_POST, 'projname', FILTER_SANITIZE_SPECIAL_CHARS);
    $startd = filter_input(INPUT_POST, 'startd', FILTER_SANITIZE_SPECIAL_CHARS);
    $endd = filter_input(INPUT_POST, 'endd', FILTER_SANITIZE_SPECIAL_CHARS);
    $projdesc = filter_input(INPUT_POST, 'projdesc', FILTER_SANITIZE_SPECIAL_CHARS);
    $estcost = filter_input(INPUT_POST, 'estcost', FILTER_SANITIZE_SPECIAL_CHARS);
    $money = filter_input(INPUT_POST, 'money', FILTER_SANITIZE_SPECIAL_CHARS);

    // Validation (Example: Ensure required fields are not empty)
    if (empty($projname) || empty($startd) || empty($endd) || empty($projdesc) || empty($estcost) || empty($money)) {
        $errors[] = "All fields are required.";
    }

    if (empty($errors)) {
        // Prepare an update statement
        $sql = "UPDATE expenses SET projname = :projname, startd = :startd, endd = :endd, projdesc = :projdesc, estcost = :estcost, budget = :money WHERE id = :id";
        $stmt = $pdo->prepare($sql);

        // Bind parameters to statement
        $stmt->bindParam(':projname', $projname);
        $stmt->bindParam(':startd', $startd);
        $stmt->bindParam(':endd', $endd);
        $stmt->bindParam(':projdesc', $projdesc);
        $stmt->bindParam(':estcost', $estcost);
        $stmt->bindParam(':money', $money);
        $stmt->bindParam(':id', $id);

        // Execute the statement
        if ($stmt->execute()) {
         		$_SESSION["success"] = "Update Successful!";
                header("location: expenses_db.php");
           }
    }
}



?>
