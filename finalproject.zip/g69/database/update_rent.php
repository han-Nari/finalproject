<?php 
	require_once "../includes/session.php";
	require_once "../includes/finance_db_connect.php";

	$errors = array("error" => "", "number" => "");
	if(isset($_GET["id"])) {
		try {
			$id = htmlspecialchars($_GET["id"]);

			$query = "SELECT * FROM rent WHERE id = :id";
			$stmt = $pdo->prepare($query);
			$stmt->bindParam(":id", $id);
			$stmt->execute();

			$results = $stmt->fetch(PDO::FETCH_ASSOC);
		} catch(PDOException $e) {
			die("Error" . $e->getMessage());
		}
	}

	if(isset($_POST["update"])) {
        $Mname = $_POST["mname"];
        $fname = $_POST["fname"];
        $lname = $_POST["lname"];
        $ramount = $_POST["ramount"];
        $payments = $_POST["payments"];
        $permits = $_POST["permits"];
        $stalls = $_POST["stalls"];
    
	   if(array_filter($errors)) {

	   } else {

		   $query = "UPDATE rent SET market_name = :mname, first_name = :first_name, last_name = :last_name, rent_amount = :rent_amount, payment_frequency = :payment_frequency, permit_number = :permit_number, stall_number = :stall_number WHERE id = :id";
 			$stmt = $pdo->prepare($query);
            $stmt->bindParam(":mname", $Mname);
            $stmt->bindParam(":first_name", $fname);
            $stmt->bindParam(":last_name", $lname);
            $stmt->bindParam(":rent_amount", $ramount);
            $stmt->bindParam(":payment_frequency", $payments);
            $stmt->bindParam(":permit_number", $permits);
            $stmt->bindParam(":stall_number", $stalls);
	        $stmt->bindParam(":id", $id);
		    $stmt->execute();
			   if($stmt) {
			   	  $_SESSION["success"] = "Update Sucessful!";
			   	   header('location: rent_db.php');
			   }
	   }
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<script type="text/javascript">
		window.history.forward();
	</script>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Edit Rental Payments</title>

	<!-- Favicon -->
	<link rel="icon" type="image/x-icon" href="../img/logo.png">

	<!-- Jquery -->
	<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
	
	<!-- ==== Icon ==== -->
	<script src="https://kit.fontawesome.com/9fd2f42e98.js" crossorigin="anonymous"></script>

	<!-- ==== Css Link ==== -->
	<style>
		<?php include "../dashboard/dash.css"; ?>
		<?php include "../finance/payments.css"; ?>
		<?php include "../finance/main.css"; ?>
		.grids {
			display: flex;
			justify-content: center;
			align-items: center;
		}

		form {
			width: 100%;
		}

		form h1 {
			text-align: center;
		}
	</style>
</head>
<body>
	<main>
	<!-- Sidebar -->
	<?php include "../dashboard/side.php";?>

	<!-- Header -->
	<?php include "../dashboard/header.php";?>

	<!-- Main content -->
		<section>
			<div class="container">
	           <div class="grids">
		           <div class="two">
		                <div id="form2" class="form-container">
		                	 <form action="<?php htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST"> 
		                    <h1>Vendors Rental Payment</h1>
		                      <label>Market Name</label> 
		                      <input type="text" name="mname" placeholder="Market Name" value="<?php echo $results["market_name"]; ?>">

		                      <label>First Name</label> 
		                      <input type="text" name="fname" placeholder="First Name" value="<?php echo $results["first_name"]; ?>">

		                      <label>Last Name</label> 
		                      <input type="text" name="lname" placeholder="Last Name" value="<?php echo $results["last_name"]; ?>">

		                      <label>Rent Amount</label> 
		                      <input type="number" name="ramount" placeholder="Rent Amount" class="no-spinner" value="<?php echo $results["rent_amount"]; ?>">

		                      <label>Payment Frequency</label>
			                  <input type="text" name="payments" value="Monthly">


		           		      <label>Permit Numbers</label>  
		                      <input type="number" name="permits" placeholder="Permit Numbers" class="no-spinner" value="<?php echo $results["permit_number"]; ?>">

		                      <label>Stall Numbers</label> 
		                      <input type="number" name="stalls" placeholder="Stall Numbers" class="no-spinner" value="<?php echo $results["stall_number"]; ?>">

		                      <button class="btn" type="submit" name="update">Submit</button>
		                    </form>
		                </div>
		            </div>
	      		</div>
	      	</div>
		</section>
	</main>
	<script>
		<?php include "../dashboard/dash.js"; ?>
	</script>
</body>
</html>



	