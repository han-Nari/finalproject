<?php 
	require_once "../includes/session.php";
	require_once "../includes/finance_db_connect.php";

	if (!isset($_SESSION["passCode"])) {
	    header('location: database.php');
	    exit;
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<script type="text/javascript">
		window.history.forward();
	</script>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Income Management</title>

	<!-- Favicon -->
	<link rel="icon" type="image/x-icon" href="../img/logo.png">

	<!-- Jquery -->
	<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
	
	<!-- ==== Icon ==== -->
	<script src="https://kit.fontawesome.com/9fd2f42e98.js" crossorigin="anonymous"></script>

	<!-- ==== Css Link ==== -->
	<style>
		<?php include "../dashboard/dash.css"; ?>
		<?php include "main.css" ?>
	</style>
</head>
<body>
	<main>
	<!-- Sidebar -->
	<?php include "../dashboard/side.php";?>

	<!-- Header -->
	<?php include "../dashboard/header.php";?>

	<!-- Main content -->
		<section class="dbase">
			 <div class="db">
		   		<a class="a button-53" href="payments_db.php">
		  	 		<span class="text">Vendors Down Payments</span>
		  	 	</a>
		  	 	<a class="a button-53" href="rent_db.php">
		  	 		<span class="text">Vendors Rental Payments</span>
		  	 	</a>
		  	 	<a class="a button-53" href="permit_db.php">
		   			<span class="text">Permit Payments</span>
		   		</a>
		  	 	<a class="a button-53" href="finance_db.php">
		   			<i class="fa-solid fa-arrow-right-arrow-left i"></i>
		   		</a>
		   </div>
		</section>
	</main>
	<script>
		<?php include "../dashboard/dash.js"; ?>
	</script>
</body>
</html>



	