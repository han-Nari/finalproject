<?php 
	require_once "../includes/session.php";
	require_once "../includes/finance_db_connect.php";
	require_once "rent_fetch.php";
	
	if (!isset($_SESSION["passCode"])) {
	    header('location: database.php');
	    exit;
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<script type="text/javascript">
		window.history.forward();
	</script>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Rental Payment Records</title>

	<!-- Favicon -->
	<link rel="icon" type="image/x-icon" href="../img/logo.png">

	<!-- Jquery -->
	<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
	
	<!-- ==== Icon ==== -->
	<script src="https://kit.fontawesome.com/9fd2f42e98.js" crossorigin="anonymous"></script>

	<!-- ==== Css Link ==== -->
	<style>
		<?php include "../dashboard/dash.css"; ?>
		<?php include "../table/table.css"; ?>
		.no-print {
            display: block;
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            font-size: 16px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
            margin-block: 1rem;
        }
        .no-print:hover {
            background-color: #0056b3;
        }
        /* Hide print button when printing */
        @media print {
            .no-print {
                display: none;
            }
        }
	</style>
</head>
<body>
	<main>
	<!-- Main content -->
		<section class="full">
			<div class="container">
				<div class="print">
					<table id="largeTable">
						<caption>
							<div class="flexible">
								<h1 class="title">Rental Payment Records</h1>
							</div>
						</caption>
						<thead>
							<tr>
								<th>Market Name</th>
		                        <th>First Name</th>
		                        <th>Last Name</th>
		                        <th>Rent Amount</th>
		                        <th>Payment Frequency</th>
		                        <th>Permit Number</th>
		                        <th>Stall Number</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach($results as $result) : ?>
								<tr>
									<td data-cell="Name"><?php echo $result["mname"]; ?></td>
									<td data-cell="First Name"><?php echo $result["first_name"]; ?></td>
									<td data-cell="Last Name"><?php echo $result["last_name"]; ?></td>
									<td data-cell="Rent Amount"><?php echo $result["rent_amount"]; ?></td>
									<td data-cell="Payment Frequency"><?php echo $result["payment_frequency"]; ?></td>
									<td data-cell="Permit Number"><?php echo $result["permit_number"]; ?></td>
									<td data-cell="Stall Number"><?php echo $result["stall_number"]; ?></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
				 <!-- "Print" button -->
                <button class="no-print" id="printButton" onclick="window.print()">Print</button>
			</div>	
		</section>
	</main>
	<script>
        // Remove the print button after printing
        window.onafterprint = function() {
            var printButton = document.getElementById("printButton");
            if (printButton) {
                printButton.style.display = "none";
            }
        };
    </script>
</body>
</html>



	