<?php 
    require_once "../includes/session.php";
    require_once "../includes/finance_db_connect.php";

    $errors = array("error" => "", "number" => "");
    if(isset($_GET["id"])) {
        try {
            $id = htmlspecialchars($_GET["id"]);

            $query = "SELECT * FROM permits WHERE id = :id";
            $stmt = $pdo->prepare($query);
            $stmt->bindParam(":id", $id);
            $stmt->execute();

            $results = $stmt->fetch(PDO::FETCH_ASSOC);
        } catch(PDOException $e) {
            die("Error" . $e->getMessage());
        }
    }

     if ($_SERVER["REQUEST_METHOD"] == "POST") {
        $fname = $_POST["fname"];
        $adr = $_POST["adr"];
        $email = $_POST["email"];
        $contact = $_POST["contact"];
        $type = $_POST["type"];
        $amount = $_POST["amount"];

       if(array_filter($errors)) {

       } else {

            $query = "UPDATE permits SET full_name = :full_name, address = :address, email = :email, contact_number = :contact_number, permit_type = :permit_type, amount = :amount WHERE id = :id";
            $stmt = $pdo->prepare($query);
            $stmt->bindParam(":full_name", $fname);
            $stmt->bindParam(":address", $adr);
            $stmt->bindParam(":email", $email);
            $stmt->bindParam(":contact_number", $contact);
            $stmt->bindParam(":permit_type", $type);
            $stmt->bindParam(":amount", $amount);
            $stmt->bindParam(":id", $id);
            $stmt->execute();

           if($stmt) {
              $_SESSION["success"] = "Update Sucessful!";
               header('location: permit_db.php');
           }
       }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <script type="text/javascript">
        window.history.forward();
    </script>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Permit Payments</title>

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="../img/logo.png">

    <!-- Jquery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    
    <!-- ==== Icon ==== -->
    <script src="https://kit.fontawesome.com/9fd2f42e98.js" crossorigin="anonymous"></script>

    <!-- ==== Css Link ==== -->
    <style>
        <?php include "../dashboard/dash.css"; ?>
        <?php include "../finance/expense.css"; ?>
    </style>
</head>
<body>
    <main>
    <!-- Sidebar -->
    <?php include "../dashboard/side.php";?>

    <!-- Header -->
    <?php include "../dashboard/header.php";?>

    <!-- Main content -->
    <section>
        <div class="container">
            <form action="<?php htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST"> 
                <h1>Payment For Permit</h1>

                <label for="fname">Full name</label>
                <input type="text" id="fname" name="fname" placeholder="Full name" value="<?php echo $results["full_name"]; ?>">
                
                <label for="adr">Address</label>
                <input type="text" id="adr" name="adr" placeholder="Address" value="<?php echo $results["address"]; ?>">
                
                <label for="email">Email</label>
                <input type="text" id="email" name="email" placeholder="Email" value="<?php echo $results["email"]; ?>">

                <label for="contact">Contact number</label>
                <input type="number" id="contact" name="contact" placeholder="Contact number" value="<?php echo $results["contact_number"]; ?>">

                <label for="type">Permit Type</label>
                <select id="type" name="type">
                    <option value="Barangay Clearance">Barangay Clearance</option>
                    <option value="Business Permit">Business Permit</option>
                    <option value="Certificate of Indigency">Certificate of Indigency</option>
                </select>

                <label for="amount">Amount</label>
                <input type="number" id="amount" name="amount" placeholder="Amount" class="no-spinner" value="<?php echo $results["amount"]; ?>">
                
                <input class="btn" type="submit" name="submit" value="Update">
            </form>
        </div>
    </section>
    </main>
    <script>
    <?php include "../dashboard/dash.js"; ?>
    </script>
</body>
</html>
