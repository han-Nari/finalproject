<?php 
	require_once "../includes/session.php";
	require_once "../includes/finance_db_connect.php";
	require_once "expenses_db_fetch.php";
	require_once "delete_expense.php";
	require_once "update_expense.php";
	
	if (!isset($_SESSION["passCode"])) {
	    header('location: database.php');
	    exit;
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<script type="text/javascript">
		window.history.forward();
	</script>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Expenses Management Records</title>

	<!-- Favicon -->
	<link rel="icon" type="image/x-icon" href="../img/logo.png">

	<!-- Jquery -->
	<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
	
	<!-- ==== Icon ==== -->
	<script src="https://kit.fontawesome.com/9fd2f42e98.js" crossorigin="anonymous"></script>

	<!-- ==== Css Link ==== -->
	<style>
		<?php include "../dashboard/dash.css"; ?>
		<?php include "../table/table.css"; ?>
		<?php include "main.css"; ?>
	</style>
</head>
<body>
	<main>
	<!-- Sidebar -->
	<?php include "../dashboard/side.php";?>

	<!-- Header -->
	<?php include "../dashboard/header.php";?>

	<!-- Main content -->
		<section>
			<?php if(isset($_SESSION["success"])) : ?>
					<div class="update">
						<strong><?php echo $_SESSION["success"];?></strong>
						<i class="fa-solid fa-xmark remove"></i>
					</div>
					<?php unset($_SESSION["success"]); ?>
			<?php endif; ?>

			<?php if(isset($_SESSION["delete"])) : ?>
					<div class="update deleted">
						<strong><?php echo $_SESSION["delete"];?></strong>
						<i class="fa-solid fa-xmark remove"></i>
					</div>
					<?php unset($_SESSION["delete"]); ?>
			<?php endif; ?>
			<div class="container">
				<div class="back">
					<a class="button-86" href="finance_db.php">
		   				<i class="fa-solid fa-arrow-right-arrow-left i"></i>
		   			</a>
				</div>
				<div class="auto">
					<table id="infoTable">
						<caption>
							<div class="flexible">
								<a class="print" target="_blank" href="print_expenses.php">
									<i class="fa-solid fa-print"></i>
									<span class="printer">Save</span>
								</a>
									<div class="search">
										<input type="text" id="searchInput" onkeyup="searchTable()" placeholder="Search...">
										<i id="search" class="fa-solid fa-magnifying-glass"></i>
									</div>
								</div>
							</div>
						</caption>
						<thead>
							<tr>
								<th>Project Name</th>
								<th>Start Date</th>
								<th>End Date</th>
								<th>Project Description</th>
								<th>Estimated Cost</th>
								<th>Budget</th>
								<th>Reference No</th>
								<th>Update</th>
								<th>Delete</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach($results as $result) : ?>
								<tr>
									<td data-cell="Project Name"><?php echo $result["projname"]; ?></td>
									<td data-cell="Start Date"><?php echo $result["startd"]; ?></td>
									<td data-cell="End Date"><?php echo $result["endd"]; ?></td>
									<td data-cell="Project Description"><?php echo $result["projdesc"]; ?></td>
									<td data-cell="Estimated Cost"><?php echo $result["estcost"]; ?></td>
									<td data-cell="Budget"><?php echo $result["budget"]; ?></td>
									<td data-cell="Reference No"><?php echo $result["reference_number"]; ?></td>
									<td data-cell="Update"><a class="edit" href="expense_update.php?id=<?php echo htmlspecialchars($result["id"]); ?>">Update</a></td>
									<td data-cell="Delete">
										<form action="<?php htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">	
											<button onclick="return confirm('Do you want to delete <?php echo $result["projname"]; ?>')" id="delete_button" type="submit" name="delete" class="delete" value="<?php echo htmlspecialchars($result["id"]); ?>">Delete</button>
											<a href="javascript:void"></a>
										</form>
									</td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			</div>	
		</section>
	</main>
	<script>
		<?php include "../dashboard/dash.js"; ?>
	</script>
</body>
</html>



	