<?php 
	require_once "../includes/session.php";
	require_once "../includes/finance_db_connect.php";
	require_once "permit_fetch.php";
	
	if (!isset($_SESSION["passCode"])) {
	    header('location: database.php');
	    exit;
	}
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<script type="text/javascript">
		window.history.forward();
	</script>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Rental Payment Records</title>

	<!-- Favicon -->
	<link rel="icon" type="image/x-icon" href="../img/logo.png">

	<!-- Jquery -->
	<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
	
	<!-- ==== Icon ==== -->
	<script src="https://kit.fontawesome.com/9fd2f42e98.js" crossorigin="anonymous"></script>

	<!-- ==== Css Link ==== -->
	<style>
		<?php include "../dashboard/dash.css"; ?>
		<?php include "../table/table.css"; ?>
		.no-print {
            display: block;
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            font-size: 16px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
            margin-block: 1rem;
        }
        .no-print:hover {
            background-color: #0056b3;
        }
        /* Hide print button when printing */
        @media print {
            .no-print {
                display: none;
            }
        }
	</style>
</head>
<body>
	<main>
	<!-- Main content -->
		<section class="full">
			<div class="container">
				<div class="print">
					<table id="largeTable">
						<caption>
							<div class="flexible">
								<h1 class="title">Permit Payments Records</h1>
							</div>
						</caption>
						<thead>
							<tr>
								<th>Full Name</th>
								<th>Address</th>
								<th>Email</th>
								<th>Contact Number</th>
								<th>Business Owner</th>
								<th>Business Name</th>
								<th>Permit Type</th>
								<th>Amount</th>
								<th>Business Address</th>
								<th>Reference No</th>
								<th>Status</th>
							</tr>
						</thead>
						<tbody>
							<?php foreach($results as $result) : ?>
								<tr>
									<td data-cell="Full Name"><?php echo $result["full_name"]; ?></td>
									<td data-cell="Address"><?php echo $result["address"]; ?></td>
									<td data-cell="Email"><?php echo $result["email"]; ?></td>
									<td data-cell="Contact Number"><?php echo $result["contact_number"]; ?></td>
									<td data-cell="Business Owner"><?php echo $result["business_owner"]; ?></td>
									<td data-cell="Business Name"><?php echo $result["business_name"]; ?></td>
									<td data-cell="Permit Type"><?php echo $result["permit_type"]; ?></td>
									<td data-cell="Amount"><?php echo $result["amount"]; ?></td>
									<td data-cell="Business Address"><?php echo $result["business_address"]; ?></td>
									<td data-cell="Reference No"><?php echo $result["reference_number"]; ?></td>
									<td data-cell="Status"><?php echo $result["status"]; ?></td>
								</tr>
							<?php endforeach; ?>
						</tbody>
					</table>
				</div>
				 <!-- "Print" button -->
                <button class="no-print" id="printButton" onclick="window.print()">Print</button>
			</div>	
		</section>
	</main>
	<script>
        // Remove the print button after printing
        window.onafterprint = function() {
            var printButton = document.getElementById("printButton");
            if (printButton) {
                printButton.style.display = "none";
            }
        };
    </script>
</body>
</html>



	