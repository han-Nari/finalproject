<?php 
    require_once "../includes/session.php";
    require_once "../includes/finance_db_connect.php";
    require_once "payments_fetch.php";

    if (!isset($_SESSION["passCode"])) {
        header('location: database.php');
        exit;
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <script type="text/javascript">
        window.history.forward();
    </script>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Save Vendors Payment</title>

    <!-- Favicon -->
    <link rel="icon" type="image/x-icon" href="../img/logo.png">

    <!-- Jquery -->
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    
    <!-- ==== Icon ==== -->
    <script src="https://kit.fontawesome.com/9fd2f42e98.js" crossorigin="anonymous"></script>

    <!-- ==== Css Link ==== -->
    <style>
        <?php include "../dashboard/dash.css"; ?>
        <?php include "../table/table.css"; ?>
        /* Button styling */
        .no-print {
            display: block;
            margin-block: 1rem;
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            font-size: 16px;
            border-radius: 5px;
            transition: background-color 0.3s ease;
        }
        .no-print:hover {
            background-color: #0056b3;
        }
        /* Hide print button when printing */
        @media print {
            .no-print {
                display: none;
            }
        }
    </style>
</head>
<body>
    <main>
    <!-- Main content -->
        <section class="full">
            <div class="container">
                <div class="print">
                    <table id="largeTable">
                        <caption>
                            <h1 class="title">Vendors Records</h1>
                        </caption>
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Market Name</th>
                                <th>Stall Numbers</th>
                                <th>Permit Numbers</th>
                                <th>Amount</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($results as $result) : ?>
                                <tr>
                                    <td data-cell="Name"><?php echo $result["name"]; ?></td>
                                    <td data-cell="Market Name"><?php echo $result["market_name"]; ?></td>
                                    <td data-cell="Stall Numbers"><?php echo $result["stall_numbers"]; ?></td>
                                    <td data-cell="Permit Numbers"><?php echo $result["permit_numbers"]; ?></td>
                                    <td data-cell="Amount"><?php echo $result["amount"]; ?></td>
                                    <td data-cell="Status"><?php echo $result["status"]; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <!-- "Print" button -->
                <button class="no-print" id="printButton" onclick="window.print()">Print</button>
            </div>  
        </section>
    </main>
    <script>
        // Remove the print button after printing
        window.onafterprint = function() {
            var printButton = document.getElementById("printButton");
            if (printButton) {
                printButton.style.display = "none";
            }
        };
    </script>
</body>
</html>
