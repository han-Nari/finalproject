<?php 

$dsn = "mysql:host=localhost;dbname=grou_financial";
$dbusername = 'grou_group69';
$dbpass = 'felixabungan123';

try {
	// DSN
	$pdo = new PDO($dsn, $dbusername, $dbpass);
	$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
	$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

	// if($pdo) {
	// 	echo "connected";
	// }

} catch(PDOException $e) {
	die("Connection failed" . $e->getMessage());
}