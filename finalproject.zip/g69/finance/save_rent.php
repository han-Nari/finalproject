<?php 
$errors = array("error" => "");

function generateReferenceNumber() {
    return uniqid(); // You can use any other method to generate a unique reference number as per your requirement
}

if(isset($_POST["submit"])) {
    $market_name = $_POST["mname"];
    $ramount = $_POST["ramount"];
    $referenceNumber = generateReferenceNumber();

    // Prepare SQL statement to check if the project name exists
    $query = "SELECT COUNT(*) as count FROM rent WHERE market_name = :market_name";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(":market_name", $market_name);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    // If the tracking code exists
    if($row['count'] > 0) {
        // Update the amount in the existing row
        $query = "UPDATE rent SET market_name = :market_name, rent_amount = rent_amount + :rent_amount, reference_number = :reference_number WHERE market_name = :market_name";
        $stmt = $pdo->prepare($query);
        $stmt->bindParam(":reference_number", $referenceNumber);
        $stmt->bindParam(":market_name", $market_name);
        $stmt->bindParam(":rent_amount", $ramount);
        $stmt->execute();
        

        // Store receipt details in session
        $_SESSION['receipt'] = [
            'referenceNumber' => $referenceNumber,
            'market_name' => $market_name,
            'ramount' => $ramount
        ];

        // Redirect back to the HTML form
        header("location: rent.php");
        exit();
    } else {
        $_SESSION['error'] = "$market_name Does not Exist.";
    }
}

