<?php 
	require_once "../includes/session.php";
	require_once "../includes/finance_db_connect.php";
	require_once "save_rent.php";
	
	unset($_SESSION["passCode"]);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<script type="text/javascript">
		window.history.forward();
	</script>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Vendors Rental Payment</title>

	<!-- Favicon -->
	<link rel="icon" type="image/x-icon" href="../img/logo.png">

	<!-- Jquery -->
	<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
	
	<!-- ==== Icon ==== -->
	<script src="https://kit.fontawesome.com/9fd2f42e98.js" crossorigin="anonymous"></script>

	<!-- ==== Css Link ==== -->
	<style>
		<?php include "../dashboard/dash.css"; ?>
		<?php include "main.css"; ?>
	</style>
</head>
<body>
	<main>
	<!-- Sidebar -->
	<?php include "../dashboard/side.php";?>

	<!-- Header -->
	<?php include "../dashboard/header.php";?>

	<!-- Main content -->
		<section>
			<div class="container">
	           <div class="grids">
		           <div class="two">
		                <div id="form2" class="form-container">
		                     <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">	

							  <h1>Vendors Rental Payment</h1>

							   <span class="errors">
                			         <?php 
                			            if(isset($_SESSION['error'])) {
                			                echo $_SESSION['error'];
                			                unset($_SESSION['error']); // Unset the session error message
                			            }
                			         ?>
                			    </span>	

		                      <label>Market Name</label> 
		                      <input type="text" name="mname" placeholder="Market Name">

		          	          <label>Rent Amount</label> 
		                      <input type="number" name="ramount" placeholder="Rent Amount" class="no-spinner">

		                      <button class="btn" type="submit" name="submit">Submit</button>
		                    </form>

		                    <?php if(isset($_SESSION['receipt']) && !empty($_SESSION['receipt']['referenceNumber']) && !empty($_SESSION['receipt']['market_name']) && !empty($_SESSION['receipt']['ramount'])): ?>
							    <div id="paymentSuccessModal" class="modal" style="display: block;">
							        <div class="modal-content">
							            <span class="close-button">&times;</span>
							            <h2 style="color: limegreen;">Payment Successful!</h2>
							            <div class="receipt" id="printableArea">
							                <h3>Receipt Details:</h3>
							                <p><strong>Reference No:</strong> <?php echo $_SESSION['receipt']['referenceNumber']; ?></p>
							                <p><strong>Market Name:</strong> <?php echo $_SESSION['receipt']['market_name']; ?></p>
							                <p><strong>Rent Amount:</strong> <?php echo $_SESSION['receipt']['ramount']; ?></p>
							                <div class="signature">
							                    <p>Cashier Signature: _____________________</p>
							                </div>
							                <button class="btn-print" onclick="printReceipt()">Print Receipt</button>
							            </div>
							        </div>
							    </div>
							    <?php unset($_SESSION['receipt']); ?>
							<?php endif; ?>

		                </div>
		            </div>
	      		</div>
	      	</div>
		</section>
	</main>
	<script>
	    document.addEventListener('DOMContentLoaded', function () {
		    // Get the modal
		    var modal = document.getElementById('paymentSuccessModal');

		    // Get the <span> element that closes the modal
		    var span = document.querySelector("#paymentSuccessModal .close-button");

		    // When the user clicks on the span (x), close the modal
		    span.onclick = function() {
		        modal.style.display = "none";
		    }

		    // When the user clicks anywhere outside of the modal, close it
		    window.onclick = function(event) {
		        if (event.target == modal) {
		            modal.style.display = "none";
		        }
		    }

		    // Show the modal
		    modal.style.display = "block";
		});

		document.addEventListener("DOMContentLoaded", function() {
            var modalContent = document.querySelector('.modal-content');
            setTimeout(function() {
                modalContent.classList.add('show');
            }, 100); // Delay for 0.1 seconds before showing to ensure transition effect
        });

		function printReceipt() {
		    var printContent = document.getElementById('printableArea');
		    var WinPrint = window.open('', '', 'width=900,height=650');

		    WinPrint.document.write(`
		        <html>
		        <head>
		            <title>Receipt</title>
		            <style>
		                body {
		                    font-family: Arial, sans-serif;
		                    padding: 20px;
		                }
		                .receipt-container {
		                    border: 1px solid #ccc;
		                    padding: 20px;
		                    max-width: 500px;
		                    margin: 0 auto;
		                    background-color: #f9f9f9;
		                }
		                .receipt-header {
		                    text-align: center;
		                    margin-bottom: 20px;
		                }
		                .receipt-details {
		                    margin-bottom: 20px;
		                }
		                .item {
		                    margin-bottom: 10px;
		                }
		                .item span {
		                    display: inline-block;
		                    width: 200px;
		                }
		                @media print {
		                    .btn-print {
		                        display: none;
		                    }
		                }
		            </style>
		        </head>
		        <body>
		            <div class="receipt-container">
		                <div class="receipt-header">
		                    <h2>Receipt</h2>
		                </div>
		                <div class="receipt-details">
		                    ${printContent.innerHTML}
		                </div>
		            </div>
		        </body>
		        </html>
		    `);

		    WinPrint.document.close();
		    WinPrint.focus();
		    WinPrint.print();
		    WinPrint.close();
		}

		<?php include "../dashboard/dash.js"; ?>
	</script>
</body>
</html>
