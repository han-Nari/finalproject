<?php 
$errors = array("error" => "", "email" => "");

function generateReferenceNumber() {
    return uniqid(); // You can use any other method to generate a unique reference number as per your requirement
}

if(isset($_POST["submit"])) {
    $tracking_code = $_POST["track"];
    $amount = $_POST["amount"];
    $referenceNumber = generateReferenceNumber();

    // Prepare SQL statement to check if the tracking code exists
    $query = "SELECT COUNT(*) as count FROM permits WHERE tracking_code = :tracking_code";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(":tracking_code", $tracking_code);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    // If the tracking code exists
    if($row['count'] > 0) {
        // Update the amount in the existing row
        $update_query = "UPDATE permits SET amount = :amount, reference_number = :reference_number WHERE tracking_code = :tracking_code";
        $update_stmt = $pdo->prepare($update_query);
        $update_stmt->bindParam(":reference_number", $referenceNumber);
        $update_stmt->bindParam(":tracking_code", $tracking_code);
        $update_stmt->bindParam(":amount", $amount);
        $update_stmt->execute();
        

        // Store receipt details in session
        $_SESSION['receipt'] = [
            'referenceNumber' => $referenceNumber,
            'trackingCode' => $tracking_code,
            'amount' => $amount
        ];

        // Redirect back to the HTML form
        header("location: permit.php");
        exit();
    } else {
        $_SESSION['error'] = "Tracking code $tracking_code Does not Exist.";
    }
}