<?php 
$errors = array("error" => "");

function generateReferenceNumber() {
    return uniqid(); // You can use any other method to generate a unique reference number as per your requirement
}

if(isset($_POST["submit"])) {
    $projname = $_POST["projname"];
    $money = $_POST["money"];
    $referenceNumber = generateReferenceNumber();

    // Prepare SQL statement to check if the project name exists
    $query = "SELECT COUNT(*) as count FROM expenses WHERE projname = :projname";
    $stmt = $pdo->prepare($query);
    $stmt->bindParam(":projname", $projname);
    $stmt->execute();
    $row = $stmt->fetch(PDO::FETCH_ASSOC);

    // If the tracking code exists
    if($row['count'] > 0) {
        // Update the amount in the existing row
        $update_query = "UPDATE expenses SET budget = :budget, reference_number = :reference_number WHERE projname = :projname";
        $update_stmt = $pdo->prepare($update_query);
        $update_stmt->bindParam(":reference_number", $referenceNumber);
        $update_stmt->bindParam(":projname", $projname);
        $update_stmt->bindParam(":budget", $money);
        $update_stmt->execute();
        

        // Store receipt details in session
        $_SESSION['receipt'] = [
            'referenceNumber' => $referenceNumber,
            'projname' => $projname,
            'budget' => $money
        ];

        // Redirect back to the HTML form
        header("location: expense.php");
        exit();
    } else {
        $_SESSION['error'] = "$projname Does not Exist.";
    }
}