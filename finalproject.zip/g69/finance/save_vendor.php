<?php   
    $errors = array("error" => "", "number" => "");

    function generateReferenceNumber() {
            return uniqid(); // You can use any other method to generate a unique reference number as per your requirement
    }
    if(isset($_POST["submit"])) {
        $name = $_POST["name"];
        $mName = $_POST["market"];
        $stall = $_POST["stall"];
        $permit = $_POST["permit"];
        $amount = $_POST["amount"];
        $referenceNumber = generateReferenceNumber();
         
        if(empty($name) || empty($mName) || empty($stall) || empty($permit) || empty($amount)) {
            $errors["error"] = "Required to fill up the form";
        }

        $_SESSION['receipt'] = [
            'reference' => $referenceNumber,
            'name' => $name,
            'market' => $mName,
            'stall' => $stall,
            'permit' => $permit,
            'amount' => $amount
        ];
    
        if(array_filter($errors)) {
            // Error
        } else {
            // Save to database
            $query = "INSERT INTO vendors (name, market_name, stall_numbers, permit_numbers, amount, reference_number) VALUES(:name, :market_name, :stall_numbers, :permit_numbers, :amount, :reference_number)";
            $stmt = $pdo->prepare($query);
            $stmt->bindParam(':reference_number', $referenceNumber);
            $stmt->bindParam(":name", $name);
            $stmt->bindParam(":market_name", $mName);
            $stmt->bindParam(":stall_numbers", $stall);
            $stmt->bindParam(":permit_numbers", $permit);
            $stmt->bindParam(":amount", $amount);
            $stmt->execute();
    
            if($stmt) {
                $_SESSION['reference'] = $referenceNumber;
                $_SESSION['payment'] = "Payment Successful!";
                header("location: down.php");
                exit();
            }
        }
    
    }
?>