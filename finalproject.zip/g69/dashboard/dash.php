<?php 
	require_once "../includes/finance_db_connect.php";
	require_once "../includes/session.php";
	require_once "../finance/expense_fetch.php";
	require_once "../rpt/taxes.php";
	require_once "../database/fetch.php";

	unset($_SESSION["passCode"]);
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<script type="text/javascript">
		window.history.forward();
	</script>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Dashboard</title>

	<!-- Favicon -->
	<link rel="icon" type="image/x-icon" href="../img/logo.png">

	<!-- Jquery -->
	<script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
	
	<!-- ==== Icon ==== -->
	<script src="https://kit.fontawesome.com/9fd2f42e98.js" crossorigin="anonymous"></script>

	<!-- ==== Css Link ==== -->
	<style>
		<?php require_once "dash.css"; ?>
		<?php require_once "../table/table.css"; ?>
	</style>
</head>
<body>
	<main>
	<!-- Sidebar -->
	<?php require_once "side.php";?>

	<!-- Header -->
	<?php require_once "header.php";?>

	<!-- Main content -->
		<section>
			<div class="grid">
				<div class="col_one">
	                <div class="cards">
	                    <span class="icons">
	                        <i class="fa-solid fa-handshake bg-1"></i>
	                        <span class="texts">Budget</span>
	                    </span>
	                    <span class="texts">
	                        <p class="count"><i class="fa-solid fa-peso-sign"><?php echo $budget ?></i></p>
	                    </span>
	                </div>
	                <div class="cards">
	                    <span class="icons">
	                        <i class="fa-solid fa-money-bill-transfer bg-5"></i>
	                        <span class="texts">Income</span>
	                    </span>
	                    <span class="texts">
	                        <p class="count"><i class="fa-solid fa-peso-sign"><?php echo $income ?></i></p>
	                    </span>
	                </div>
	                <div class="cards">
	                    <span class="icons">
	                        <i class="fa-solid fa-money-check-dollar bg-4"></i>
	                        <span class="texts">Expenses</span>
	                    </span>
	                    <span class="texts">
	                        <p class="count"><i class="fa-solid fa-peso-sign"><?php  echo $totalAmountExpenses; ?></i></p>
	                    </span>
	                </div>
	                  <div class="cards">
	                    <span class="icons">
	                        <i class="fa-solid fa-coins bg-3"></i>
	                        <span class="texts">Taxes</span>
	                    </span>
	                    <span class="texts">
	                        <p class="count"><i class="fa-solid fa-peso-sign"><?php  echo $collectedTaxes; ?></i></p>
	                    </span>
	                </div>
	            </div>

	            <div class="col_two">
	            	<!-- Financial Management Timeline -->
	            	<h1 class="titles">Financial Management Timeline</h1>
				    <div class="timeline">
				        <div class="event">
				            <div class="date">2020</div>
				            <div class="description">
				                <i class="fas fa-chart-line"></i>
				                <p>Created monthly budget plan</p>
				            </div>
				        </div>
				        <div class="event">
				            <div class="date">2020</div>
				            <div class="description">
				                <i class="fas fa-file-invoice-dollar"></i>
				                <p>Filed tax returns for the year</p>
				            </div>
				        </div>
				        <div class="event">
				            <div class="date">2021</div>
				            <div class="description">
				                <i class="fas fa-piggy-bank"></i>
				                <p>Started emergency fund savings</p>
				            </div>
				        </div>
				        <div class="event">
				            <div class="date">2021</div>
				            <div class="description">
				                <i class="fas fa-chart-pie"></i>
				                <p>Analyzed expense categories for optimization</p>
				            </div>
				        </div>
				        <div class="event">
				            <div class="date">2022</div>
				            <div class="description">
				                <i class="fas fa-hand-holding-usd"></i>
				                <p>Reduced unnecessary expenses</p>
				            </div>
				        </div>
				        <!-- Add more financial management events as needed -->
				    </div>
	            </div>

	            <div class="col_three">
	            	<h1 class="titles">Modules</h1>
	            	<a href="../connected/group61.php" class="cards-bg-3 button-53">
	                    <span class="icons gap">
	                        <div class="icons">
	                        	<i class="fa-regular fa-folder-open"></i>
	                        </div>
	                        <div>
	                        	 <span class="t2">Group 61</span>
	                        </div>
	                    </span>
	                </a>
	            	<a href="../connected/group63.php" class="carcards-bg-1 button-53">
	                    <span class="icons gap">
	                        <div class="icons">
	                        	<i class="fa-regular fa-folder-open"></i>
	                        </div>
	                        <div>
	                        	 <span class="t2">Group 63</span>
	                        </div>
	                    </span>
	                </a>
	                <a href="../connected/group67.php" class="cards-bg-2 button-53">
	                    <span class="icons gap">
	                        <div class="icons">
	                        	<i class="fa-regular fa-folder-open"></i>
	                        </div>
	                        <div>
	                        	 <span class="t2">Group 67</span>
	                        </div>
	                    </span>
	                </a>
					<a href="../connected/group68.php" class="cards-bg-3 button-53">
	                    <span class="icons gap">
	                        <div class="icons">
	                        	<i class="fa-regular fa-folder-open"></i>
	                        </div>
	                        <div>
	                        	 <span class="t2">Group 68</span>
	                        </div>
	                    </span>
	                </a>
	                <a href="../connected/records.php" class="cards-bg-3 button-53">
	                    <span class="icons gap">
	                        <div class="icons">
	                        	<i class="fa-regular fa-folder-open"></i>
	                        </div>
	                        <div>
	                        	 <span class="t2">Records</span>
	                        </div>
	                    </span>
	                </a>
	                </div>
				</div>
			</div>
		</section>
	</main>
	<script>
		<?php require_once "dash.js"; ?>
	</script>
</body>
</html>



	