<nav>
    <div class="logo">
        <div class="logos">
           <img src="../img/logo.png">
           <span class="town">Towntech Innovation</span>
        </div>
        <i class="fa-solid fa-times closed"></i>
    </div>
    <ul>
        <div class="ava">
           <img class="avatar big" src="../img/avatar.png">
            <div class="user">
                 <p>Fe L Ix</p></p>
             </div> 
        </div>
        <span class="opac">Main</span>
        <li>
            <a href="../dashboard/dash.php">
                <span class="icon"><i class="fa-solid fa-cube"></i></span>
                <span class="text">Dashboard</span>
            </a>
        </li>
        <!-- Financial Management -->
        <span class="opac">Financial Management</span>
        <li>
            <a href="../finance/expense.php">
                <span class="icon"><i class="fa-solid fa-money-bill-trend-up"></i></span>
                <span class="text">Expenses Management</span>
            </a>
        </li>
         <span class="opac">Payment Lists</span>
        <li>
            <a href="../finance/permit.php">
                <span class="icon"><i class="fa-solid fa-money-check"></i></span>
                <span class="text">Permit</span>
            </a>
        </li>
        <!-- Real Property Tax -->
        <span class="opac">Real Property Tax</span>
        <li>
            <a href="../rpt/tax.php">
                <span class="icon"><i class="fa-solid fa-money-bill"></i></span>
                <span class="text">Tax</span>
            </a>
        </li>
        <span class="opac">Records</span>
        <li>
            <a href="../database/database.php" class="right">
                <span class="icon"><i class="fa-solid fa-database"></i></span>
                <span class="text">Records</span>
            </a>
        </li>
        <span class="opac">Logout</span>
        <li>
            <a href="logout.php">
                <span class="icon"><i class="fa-solid fa-arrow-right-from-bracket"></i></span>
                <span class="text">Logout</span>
            </a>
        </li>
    </ul>
</nav>


